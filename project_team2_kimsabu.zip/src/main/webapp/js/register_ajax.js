function passwordCheckFunction() {
	let password1 = $('#password1').val();
	let password2 = $('#password2').val();
	// console.log('password1: ' + password1 + ", password2: " + password2);
	
	if (password1 != password2) {
		alert("비밀번호 불일치")
	} else {
	}
}




