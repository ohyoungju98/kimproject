window.onload =function () {
   window.open("pop.html",  "popupNo1", "width=700, height=700");
}